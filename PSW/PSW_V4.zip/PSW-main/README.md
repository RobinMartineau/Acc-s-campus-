Voici le projet PSW pour le BTS CIEL

Avant de vouloir lancer quoique ce soit, lancer ces commandes dans votre terminal

Installer les dépendances:
```bash
npm i
```

Puis:
```bash
npm run dev
```

Ensuite dirigez vous vers [http://localhost:3000](http://localhost:3000) dans votre navigateur.

Non fini, en cours de dev...
