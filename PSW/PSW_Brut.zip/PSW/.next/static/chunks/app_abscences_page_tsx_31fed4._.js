(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_abscences_page_tsx_31fed4._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_abscences_page_tsx_31fed4._.js",
  "chunks": [
    "static/chunks/_4655ab._.js"
  ],
  "source": "dynamic"
});
